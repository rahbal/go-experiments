package main

import (
	"greedygame/api"
)

func main() {
	api.NewServer()
}
